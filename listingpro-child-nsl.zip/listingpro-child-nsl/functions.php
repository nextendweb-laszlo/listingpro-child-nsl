<?php

/* ============== login based file  ============ */
if (!is_user_logged_in()) {
    $customLoginPopupFilePath = get_theme_file_path('include/lp-needlogin.php');
    if (file_exists($customLoginPopupFilePath)) {
        require_once $customLoginPopupFilePath;
    }
}

add_action('wp_enqueue_scripts', 'my_theme_enqueue_styles');
function my_theme_enqueue_styles() {
    wp_enqueue_style('listingpr-parent-style', get_template_directory_uri() . '/style.css');
}

?>
